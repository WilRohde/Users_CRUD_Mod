from flask import render_template,redirect,request
from flask_app import app
from flask_app.models.user import User

@app.route('/users')
def allUsers():
    allUsers = User.get_all()
    return render_template('index.html',users=allUsers)

@app.route('/user/new')
def newUser():
    return render_template('newUser.html')

@app.route('/user/<x>/show')
def showUser(x):
    id = int(x)
    data = {'id':x}
    readUser = User.read(data)
    return render_template('readUser.html',user = readUser)

@app.route('/user/<x>/edit')
def editUser(x):
    id = int(x)
    data = {'id':x}
    editUser = User.read(data)
    return render_template('editUser.html',user = editUser)

@app.route('/users/edit', methods=["POST"])
def postEdit():
    editUser = {'user_id':request.form['id'],
                'first_name':request.form['first_name'],
                'last_name':request.form['last_name'],
                'email':request.form['email']}
    print("=====================editUser============================")
    print(editUser)
    User.update(editUser)
    return redirect('/users')

@app.route('/user/<x>/delete')
def deleteUser(x):
    id = int(x)
    data = {'id':x}
    User.delete(data)
    return redirect('/users')

@app.route('/user/create',methods=["POST"])
def createUser():
    newUser = { 'first_name':request.form['first_name'],
                'last_name':request.form['last_name'],
                'email':request.form['email']}
    User.create(newUser)
    return redirect('/users')
